﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.LiskovSubstitution.Models
{
    public class Car
    {
        public int Seats { get; set; }
        public int Horsepower { get; set; }
        public string Color { get; set; }
        public int Gear { get; set; }
        public bool IsRunning { get; set; }

        public void StartCar()
        {
            IsRunning = true;
        }

        public void StopCar()
        {
            IsRunning = false;
        }

        public virtual void ShiftGearUp()
        {
            Gear += 1;
        }

        public virtual string PrintUsefulInfo()
        {
            return
                "Welcome to the random car.";
        }

        public virtual string PrintCurrentGear()
        {
            return $"I'm currently in gear {Gear}";
        }

    }
}