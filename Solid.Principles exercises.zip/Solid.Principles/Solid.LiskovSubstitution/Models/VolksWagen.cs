﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.LiskovSubstitution.Models
{
    public class VolksWagen:Car
    {
        public override void ShiftGearUp()
        {
            if (Gear < 5)
            {
                Gear += 1;
            }
        }

        public override string PrintUsefulInfo()
        {
            return
                $"Welcome to the {Color} Volkswagen: With {Seats} seats and {Horsepower}hp.";
        }
    }
}