﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.LiskovSubstitution.Models
{
    public class Tesla:Car
    {
        public int BatteryCapacity { get; set; }

        public override string PrintUsefulInfo()
        {
            return
                $"Welcome to the {Color} Tesla: With {Seats} seats and {Horsepower}hp. It has a {BatteryCapacity} mAh battery.";
        }
    }
}