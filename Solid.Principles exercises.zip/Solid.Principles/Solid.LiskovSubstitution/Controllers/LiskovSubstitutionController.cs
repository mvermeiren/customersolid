﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Solid.LiskovSubstitution.Models;
using Solid.LiskovSubstitution.ViewModels;

namespace Solid.LiskovSubstitution.Controllers
{
    public class LiskovSubstitutionController : Controller
    {
        public ActionResult Index()
        {
            Car auto = new Car()
            {
                Seats = 5,
                Color = "Black",
                Horsepower = 120,
                Gear = 0,
                IsRunning = false
            };

            auto.StartCar();

            var rnd = new Random();
            var randomShifts = rnd.Next(1,10);

            for (int i = 0; i < randomShifts; i++)
            {
                auto.ShiftGearUp();
            }

            var viewModel = new CarViewModel()
            {
                UsefulInfo = $"{auto.PrintUsefulInfo()} {auto.PrintCurrentGear()}"
            };

            return View("Car", viewModel);
        }
    }
}