﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Solid.LiskovSubstitution.Models;

namespace Solid.LiskovSubstitution.ViewModels
{
    public class CarViewModel
    {
        public string UsefulInfo { get; set; }

    }
}