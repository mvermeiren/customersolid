﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Solid.OpenClosed.Models;

namespace Solid.OpenClosed.Controllers
{
    public class OpenClosedController : Controller
    {

        public ActionResult Youth()
        {
            var account = new YouthBankAccount()
            {
                AccountHolderName = "Lil Benjamin",
                Age = 8,
                AccountNumber = "000-849948-5460",
                Balance = 100
            };

            return View("Youth", account);
        }

        public ActionResult Company()
        {
            var account = new CompanyBankAccount()
            {
                AccountHolderName = "Axxes",
                CompanyNumber = "BE0462.721.177",
                AccountNumber = "000-012540-9600",
                Balance = 100
            };

            return View("Company", account);
        }


        public ActionResult CalculateCompanyInterest(CompanyBankAccount account)
        {
            ModelState.Clear();
            account.Balance = InterestCalculator.CalculateNewBalance(account);

            return View("Company", account);
        }

        public ActionResult CalculateYouthInterest(YouthBankAccount account)
        {
            ModelState.Clear();
            account.Balance = InterestCalculator.CalculateNewBalance(account);

            return View("Youth", account);
        }
    }
}