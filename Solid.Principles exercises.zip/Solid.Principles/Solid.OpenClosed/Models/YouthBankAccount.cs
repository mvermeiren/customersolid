﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.OpenClosed.Models
{
    public class YouthBankAccount
    {
        public string AccountNumber { get; set; }
        public string AccountHolderName { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public int Balance { get; set; }

    }
}