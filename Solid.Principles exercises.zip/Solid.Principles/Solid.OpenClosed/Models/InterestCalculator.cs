﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.OpenClosed.Models
{
    public static class InterestCalculator
    {

        public static int CalculateNewBalance(object account)
        {
            var newBalance = 0;

            if (account is CompanyBankAccount)
            {
                CompanyBankAccount companyBankAccount = (CompanyBankAccount) account;
                newBalance = companyBankAccount.Balance += Convert.ToInt32(companyBankAccount.Balance * .1);
            }

            if (account is YouthBankAccount)
            {
                YouthBankAccount youthBankAccount = (YouthBankAccount)account;

                if (youthBankAccount.Age < 12)
                {
                    newBalance = youthBankAccount.Balance += Convert.ToInt32(youthBankAccount.Balance * .2);
                }
                else
                {
                    newBalance = youthBankAccount.Balance += Convert.ToInt32(youthBankAccount.Balance * .1);
                }
            }

            return newBalance;
        }
    }
}