﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solid.InterfaceSegregation.Models
{
    interface IBaseCar
    {
        string FuelType { get; set; }
        string TypeOfGas { get; set; }
        string Brand { get; set; }
        string Model { get; set; }
        string Version { get; set; }
        int PowerInHp { get; set; }
        int NumberOfSeats { get; set; }
        int FuelTankSizeInLiters { get; set; }
        int FuelTankSizeInKilo { get; set; }
        int BatterySizeInKwh { get; set; }
        List<String> StickeredSponsors { get; set; }
        int NumberOfPossibleBabySeats { get; set; }


    }
}
