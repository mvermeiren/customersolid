﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.InterfaceSegregation.Models
{
    public class ElectricCar:IBaseCar
    {
        public string FuelType { get; set; }
        public string TypeOfGas { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Version { get; set; }
        public int PowerInHp { get; set; }
        public int NumberOfSeats { get; set; }
        public int FuelTankSizeInLiters { get; set; }
        public int FuelTankSizeInKilo { get; set; }
        public int BatterySizeInKwh { get; set; }
        public List<string> StickeredSponsors { get; set; }
        public int NumberOfPossibleBabySeats { get; set; }
    }
}