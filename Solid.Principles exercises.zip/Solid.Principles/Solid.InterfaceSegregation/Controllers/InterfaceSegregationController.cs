﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Solid.InterfaceSegregation.Models;
using Solid.InterfaceSegregation.ViewModels;

namespace Solid.InterfaceSegregation.Controllers
{
    public class InterfaceSegregationController : Controller
    {
        public ActionResult Index()
        {
            var viewModel = new CarsViewModel();

            viewModel.ElectricCar = new ElectricCar()
            {
                FuelType = "Electric",
                Brand = "Tesla",
                Model = "Model S",
                Version = "P100D",
                PowerInHp = 259,
                NumberOfSeats = 5,
                BatterySizeInKwh = 100,
                NumberOfPossibleBabySeats = 2
            };

            viewModel.PetrolDieselCar = new PetrolDieselCar()
            {
                FuelType = "Diesel",
                Brand = "Volvo",
                Model = "V40",
                Version = "D2 Kinetic",
                PowerInHp = 120,
                NumberOfSeats = 5,
                FuelTankSizeInLiters = 50,
                NumberOfPossibleBabySeats = 2
            };

            viewModel.FamilyCar = new FamilyCar()
            {
                TypeOfGas = "CNG",
                Brand = "Ford",
                Model = "Model",
                Version = "Version",
                PowerInHp = 90,
                NumberOfSeats = 5,
                FuelTankSizeInKilo = 30,
                NumberOfPossibleBabySeats = 3
            };

            viewModel.RaceCar = new RaceCar()
            {
                FuelType = "Petrol",
                Brand = "Nissan",
                Model = "Model",
                Version = "Version",
                PowerInHp = 450,
                NumberOfSeats = 2,
                FuelTankSizeInLiters = 40,
                StickeredSponsors = new List<string>() { "Shell", "Axxes"}
            };

            return View("Index", viewModel);
        }
    }
}