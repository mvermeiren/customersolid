﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Solid.InterfaceSegregation.Models;

namespace Solid.InterfaceSegregation.ViewModels
{
    public class CarsViewModel
    {

        public ElectricCar ElectricCar { get; set; }
        public FamilyCar FamilyCar { get; set; }
        public PetrolDieselCar PetrolDieselCar { get; set; }
        public RaceCar RaceCar { get; set; }

    }
}