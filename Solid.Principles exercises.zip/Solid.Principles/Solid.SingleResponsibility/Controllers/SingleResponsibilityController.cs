﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Solid.SingleResponsibility.Models;

namespace Solid.SingleResponsibility.Controllers
{
    public class SingleResponsibilityController : Controller
    {
        public ActionResult Index()
        {
            var account = new BankAccount()
            {
                AccountHolderName = "Axxes",
                CompanyNumber = "BE0462.721.177",
                AccountNumber = "000-849948-5460",
                Balance = 100
            };

            return View(account);
        }

        public ActionResult CalculateInterest(BankAccount account)
        {
            ModelState.Clear();
            account.AddInterest();

            return View("SendStatement", account);
        }

        public ActionResult SendAccountStatement(BankAccount account)
        {
            var succes = account.SendAccountStatement();
            if (succes)
            {
                return View("Succes", account);
            }

            return View("Error");
        }
    }
}