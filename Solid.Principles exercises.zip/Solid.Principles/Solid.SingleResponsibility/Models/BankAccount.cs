﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.SingleResponsibility.Models
{
    public class BankAccount
    {
        public string AccountNumber { get; set; }
        public string AccountHolderName { get; set; }
        public string Address { get; set; }
        public string CompanyNumber { get; set; }
        public int Balance { get; set; }

        public void AddInterest()
        {
            Balance += Convert.ToInt32(Balance * 0.1);
        }

        public bool SendAccountStatement()
        {
           //Send the statement
            return true;
        }

    }
}