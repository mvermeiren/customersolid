﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Solid.DependencyInversion.Models;

namespace Solid.DependencyInversion.Controllers
{
    public class DependencyInversionController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult RunProcess()
        {
            var processor = new Processor();
            processor.RunProcessAndSendLogToAdmin();

            return View("Succes");
        }
    }
}