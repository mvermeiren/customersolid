﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Solid.DependencyInversion.Models.Loggers
{
    public class TextFileLogger
    {

        public void LogMessage(string message)
        {
            // Open text file
            // Write message
            // Close text file
        }

    }
}